

def test_generic():
    a=5
    b=5
    assert a == b