from setuptools import setup, find_packages

setup(
    name="src_new",
    version="0.0.1",
    description="its a new wine Q package",
    author="somalkant",
    packages=find_packages(),
    license="MIT"
)